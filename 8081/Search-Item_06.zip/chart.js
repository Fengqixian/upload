
(function (window, d3) {

"use strict";

// avoid duplicated regist
if (window.logicalTree) {
  return console.warn("logicalTree is registered!");
}

// original pack tree have no child
var rData = {
    "name": "ROOT",
    "type": "or",
    "children": []
};

// svg width(d) and height(h) are configuable
var w = 1000, h = 550, cRadius = 50,
  logicalTree, // exposed API object
  vm, // pop window
  svg, gMain;

var uuid = (function () {
  var i = 0, prefix = "w", f;
  f = function () { return prefix + "" + i++; };
  f.prefix = function (v) { prefix = v; return f; };
  return f;
})();

// extract tspan text based on bind data
var appendText = function (selection, d) {
  var f = [], i = 0, q = d.data.bind.querys,
      y = {"4": -30, "3": -20, "2": -10, "1": 0};
  f.push("[" + d.data.bind.collection + "]");
  while (q[i] && i < 3) {
    f.push(q[i].name + " " + q[i].logic + " " + q[i].query);
    i++;
  }

  selection.select(".svg__text").remove();
  selection.append("text")
    .attr("class", "svg__text")
    .attr("y", y[f.length])
    .attr("clip-path", "url(#Text-Clip)")
    .selectAll("tspan")
    .data(f)
    .enter()
    .append("tspan")
    .attr("x", (j, i) => i ? 0 : null)
    .attr("dy", (j, i) => i ? 20 : null)
    .text(j => j);
};

// vm dialog callback function
var dataNodeUpdate = (function () {
  /**
   * _node: <g> dom node
   * _data: obj.bind
   */
  var _node, _data, fn;

  fn = function (bind) {
    // update tree
    var child = findItemFromHierarchy(rData, _data).child;
    child.bind = JSON.parse(JSON.stringify(bind));

    // update node
    var node = d3.select(_node);
    node.datum().data.bind = bind;
    node.call(appendText, node.datum());
    node.select("circle")
    .attr("r", 70)
    .transition()
    .attr("r", cRadius)
    .attr("fill", d => d.data.bind.color);

    _node = null;
    _data = null;
  };
  fn.node = function (n) { _node = n; return fn; };
  fn.data = function (d) { _data = d; return fn; };

  return fn;
})();

function clearEmptyOrOnlyOneChildLogicalNode (node, parent) {
  // checking if node is leaf node
  if (node.type == "data") { return; }

  var index;
  (parent && (index = parent.children.findIndex(function (d) { return d === node; })));

  if (parent && node.children.length == 0) {
    parent.children.splice(index, 1);
  }
  else if (parent && node.children.length == 1) {
    var nNode = node.children[0];
    parent.children.push(nNode);
    parent.children.splice(index, 1);
    clearEmptyOrOnlyOneChildLogicalNode(nNode, parent);
  }
  else {
    for (var i = 0, l = node.children.length; i < l; i++) {
      clearEmptyOrOnlyOneChildLogicalNode(node.children[i], node);
    }
  }
}

var rootInit = (function () {
  
  var loosePack = d3.pack().radius(() => cRadius).padding(15);

  var sum = function (d) { return d.value; },
      sort = function (a, b) { return b.r - a.r; },
      andNodeOnly = function (node) { return node.data.type == "and"; },
      nodeLocReassignment = function (node) {
        // container origin is the offset for children
        var x = node.x, y = node.y,
            circle,
            childNodes = node.children;
        d3.packSiblings(childNodes);
        childNodes.forEach(function (d) {
          d.x += x;
          d.y += y;
        });
        circle = d3.packEnclose(childNodes);
        node.r = circle.r;
    };

  var f = function () {
    clearEmptyOrOnlyOneChildLogicalNode(rData);

    var root = d3.hierarchy(rData).sum(sum).sort(sort),
        nodes = root.descendants();
    loosePack.size([w, h])(root);

    // find all "and" container and relocat all data nodes
    nodes
      .filter(andNodeOnly)
      .forEach(nodeLocReassignment);

    return nodes;
  };

  return f;
})();


function svgInit (id) {

  var canvasDrag = d3.drag()
    .subject(function () { return gMain.datum(); })
    .on("drag", function () {
      var x = d3.event.x, y = d3.event.y;
      gMain.datum({x: x, y: y})
          .attr("transform", "translate(" + [x, y] + ")");
    });

  svg = d3.select(id).append("svg")
    .attr("xmlns", "http://www.w3.org/2000/svg")
    .attr("version", "1.1")
    .attr("tabIndex", 0) // focus: document.activeElement
    .attr("class", "svg")
    .attr("width", w)
    .attr("height", h);

  svg.append("defs")
    .html('<clipPath id="Text-Clip"><circle r="' + (cRadius - 2) +
          '"></circle></clipPath>');

  svg.append("rect")
    .attr("class", "svg__bg")
    .attr("width", w)
    .attr("height", h)
    .call(canvasDrag)
    .on("contextmenu", function () {
      d3.event.preventDefault();
      if (vm) {
        // vm.show(callbackFn, bind)
        vm.show(logicalTree.addDataNode);
      }
    });

  gMain = svg.append("g")
    .attr("class", "svg__main")
    .datum({x: 0, y: 0})
    .attr("transform", "translate(0,0)");

} // svgInit END

function TreeNode (child, parent, grandParent) {
  this.child = child;
  this.parent = parent;
  this.grandParent = grandParent;
}
TreeNode.prototype = {
  parentRemoveNode: function (childNode) {
    var index = this.parent.children.findIndex(function (node) {
      return node === childNode;
    });
    if (index < 0) {
      return console.error("child node is NOT exist in parent node!");
    }
    this.parent.children.splice(index, 1);
  },
  removeChild: function () {
    this.parentRemoveNode(this.child);
  },
  parentAdd: function (node) { // an node or an node array
    if (node instanceof Array) {
      Array.prototype.push.apply(this.parent.children, node);
    }
    else {
      this.parent.children.push(node);
    }
  },
  childAdd: function (node) { // an node or an node array
    if (!this.child.children) {
      return console.error("child is a prime node that can NOT contain any sub nodes.");
    }

    if (node instanceof Array) {
      Array.prototype.push.apply(this.child.children, node);
    }
    else {
      this.child.children.push(node);
    }
  }
};

function findItemFromHierarchy (hierarchyData, nodeData) {
  // [currentNode, parentNode, grandParentNode, ... root]
  var path     = nodeData.ancestors(),
      length   = path.length,
      i        = length - 2,
      child  = hierarchyData,
      grandParent,
      parent,
      name;
  while (i >= 0) {
    name = path[i].data.name;
    grandParent = parent;
    parent = child;
    child = child.children.find(function (d) { return d.name === name; });
    i--;
  }

  return new TreeNode(child, parent, grandParent);
}


function onDataNodeDBLClick (d) {
  if (d.data.type !== "data" || !vm) { return; }

  vm.show(
    dataNodeUpdate.data(d).node(this),
    JSON.parse(JSON.stringify(d.data.bind))
  );
}

function onNodeContextmenu (d) {
  d3.event.preventDefault();

  var node = findItemFromHierarchy(rData, d);

  // dataNode under the ROOT will be removed after user confirmed
  if (node.parent.name == "ROOT" && node.child.type == "data") {
    if (window.confirm("确认删除该节点？")) {
      node.removeChild();
      return nodesUpdate(rootInit());
    }
    return;
  }

  // this code block will never be excuted as for 
  // orNode point-event is set to none.
  if (node.child.type == "or") {
    node.removeChild();
    node.parentAdd(node.child.children);
    return nodesUpdate(rootInit());
  }

  if (
      (node.child.type == "data") &&
      (node.parent.type == "and" || node.parent.type == "or")
    ) {
    node.removeChild();
    node.grandParent.children.push(node.child);
    return nodesUpdate(rootInit());
  }
} // onNodeContextmenu END

var onCtrClick = (function () {
  var pickedNodes = [],
      keyCode = 17; // Ctr key

  // global keypress listener
  var keyUp = function () {
    // In case ctr is pressed while pressing other keys
    if (d3.event.keyCode != keyCode) { return; }

    // remove keyUp listener
    d3.select(this).on("keyup.ctr", null);

    var subChildren = [], rootChildren = rData.children;

    // if picked node is less than 2 or all ROOT nodes are picked will do nothing
    if (pickedNodes.length < 2 || pickedNodes.length == rootChildren.length ) {
      gMain.selectAll(".svg__picked").classed("svg__picked", false);
      return;
    }

    rootChildren.push({ name: uuid(), type: "or", children: subChildren });
    pickedNodes.forEach(function (node) {
      var name, index, target;
      name   = d3.select(node).datum().data.name;
      index  = rootChildren.findIndex(function (d) { return d.name === name; });
      target = rootChildren.splice(index, 1)[0];
      subChildren.push(target);
    });

    gMain.selectAll(".svg__picked").classed("svg__picked", false);
    nodesUpdate(rootInit());
  };
  var onKeydown = function () {
    if (d3.event.keyCode != keyCode) { return; }
    pickedNodes = []; // clear content
    d3.select(this).on("keyup.ctr", keyUp);
  };
  d3.select(window).on("keydown.ctr", onKeydown);


  var click = function (d) {
    /**
     * 1) Ctrl key should be enabled
     * 2) only dataNode is pickable
     * 3) dataNode but its parent node is orNode and is not the ROOT
     */
    if (
      !d3.event.ctrlKey ||
      d.data.type !== "data" ||
      (d.parent.data.type == "or" && d.parent.data.name !== "ROOT")
    ) { return; }

    var self = this, index;
    if (d.parent.data.type == "and") {
      self = gMain
        .selectAll(".svg__node")
        .filter(function ($) { return $ === d.parent; })
        .nodes()[0];
    }
    self.classList.toggle("svg__picked");
    index = pickedNodes.findIndex(function (node) {
      return node === self;
    });

    // if this node is included in pickNodes remove it,
    // or push it into pickNodes.
    index > -1 ? pickedNodes.splice(index, 1) : pickedNodes.push(self);
  };

  return click;
})();

var nodeDrag = (function () {
  // nodeList is a live HTMLCollection object which contained all g-nodes under gMain
  // nodesArray is an alternaltive to nodeList except needed repeately updated
  var nodeList, nodesArray = [];

  var targetNode    = null, // node element, this element will comparing with matchNodes
      triggeredNode = null, // one of "matchNodes" member which have insection with targetNode
      relatedNodes  = [],   // targetNode's related nodes, if any.
      matchNodes    = [];   // targetNode's match node array.

  // calculation functions
  var slice = Array.prototype.slice,
      getDistance = function (c1, c2) {
        return Math.sqrt((c1.x - c2.x) * (c1.x - c2.x) + (c1.y - c2.y) * (c1.y - c2.y));
      },
      innerReset = function () {
        targetNode    = null;
        triggeredNode = null;
        relatedNodes  = [];
        matchNodes    = [];
        nodesArray    = [];
      };

  function onDragStart (d) {

    // In case onEnd event don't trigged by user,
    // reassure every thing on the same page.
    innerReset();

    // update nodesArray
    nodeList = nodeList || gMain.node().getElementsByClassName("svg__node");
    nodesArray = slice.call(nodeList, 0);

    var self = this, parent = d.parent, descendants;
    if (parent.data.type == "or") {
      targetNode = self;
      descendants = d.descendants();
      nodesArray.forEach(function (node) {
        if (self === node) { return; }

        var datum = d3.select(node).datum(),
            children = parent.children; // or-Node's children
        if (children.includes(datum)) { matchNodes.push(node); return; }
        if (d.children && descendants.includes(datum)) { relatedNodes.push(node); }
      });
    }
    else { // d.parent.data.type == "and"
      targetNode = nodesArray.find(function (node) {
        return d3.select(node).datum() === parent;
      });
      descendants = parent.descendants();

      nodesArray.forEach(function (node) {
        //if (self === node) { return; }

        var datum = d3.select(node).datum(),
            children = parent.parent.children; // or-Node's children
        if (descendants.includes(datum)) { relatedNodes.push(node); return; }
        if (children.includes(datum)) { matchNodes.push(node); }
      });
    }
    
  } // onDragStart__End

  function onDrag (d) {
    var x  = d3.event.x,  y  = d3.event.y,
        dx = d3.event.dx, dy = d3.event.dy;

    /**
     * Detecting if targetNode moved outside of parentNode's domain,
     * if it does stop coordinates updating by skipping onDrag loop.
     * targetNode under the ROOT will be excepted.
     */
    var moveCircle = (this === targetNode ? d : d3.select(targetNode).datum()),
        fenceCircle = moveCircle.parent,
        maxDis1 = fenceCircle.r - d.r - 1,
        maxDis2 = fenceCircle.r - moveCircle.r - 1;
    if (
        (fenceCircle.data.name != "ROOT") &&
        (
          ((moveCircle === d) && (getDistance(fenceCircle, {x: x, y: y}) > maxDis1)) ||
          ((moveCircle !== d) && (getDistance(fenceCircle, {x: moveCircle.x + dx, y: moveCircle.y + dy}) > maxDis2))
        )
      ) {
        return;
    } // true: stop onDrag loop, code underbelow will not be excuted.
    
    if (this === targetNode) {
      Object.assign(d, {x: x, y: y});
      d3.select(this).attr("transform", "translate(" + [x, y] + ")");
    }
    relatedNodes.forEach(function (node) {
      var _node = d3.select(node), datum = _node.datum();
      datum.x += dx;
      datum.y += dy;
      _node.attr("transform", "translate(" + [datum.x, datum.y] + ")");
    });

    /**
     * This code block used for testing if targetNode have intersection with matchNodes.
     * Find the triggeredNode which is the closest node to targetNode and should 
     * have intersection with it too.
     */
    var wanted = matchNodes.map(function (node) {
      var dm = d3.select(node).datum(),
          dt = d3.select(targetNode).datum(),
          distance = getDistance(dm, dt),
          isIntersected = (distance <= Math.abs(dt.r + dm.r));
      return {
        node         : node,
        distance     : distance,
        isIntersected: isIntersected
      };
    })
    .sort(function (a, b) { return a.distance - b.distance; })
    .find(function (d) { return d.isIntersected; });

    (triggeredNode && triggeredNode.classList.remove("svg__active"));
    if (wanted) {
      triggeredNode = wanted.node;
      triggeredNode.classList.toggle("svg__active");
    }
    else {
      triggeredNode = null;
    }

    d3.select(targetNode).classed("svg__active", true);
  } // onDrag End

  function onDragEnd (d) {
    gMain.selectAll(".svg__active").classed("svg__active", false);

    if (!triggeredNode) { return innerReset(); }
    
    var target = d3.select(targetNode).datum(),
        trigger = d3.select(triggeredNode).datum(),
        tt = findItemFromHierarchy(rData, target),
        tg = findItemFromHierarchy(rData, trigger);

    // 1) If two dataNodes come close merge them into a new andNode
    if (target.data.type == "data" && trigger.data.type == "data") {
      tt.removeChild();
      tg.removeChild();
      tt.parentAdd({
        name: uuid(),
        type: "and",
        children: [tt.child, tg.child]
      });
    }

    // 2) If two andNodes come close tt grow into a bigger andNode and remove tg
    else if (target.data.type == "and" && trigger.data.type == "and") {
      tg.removeChild();
      tt.childAdd(tg.child.children);
    }

    // 3) If two orNodes come close merge them into a new bigger orNode
    else if (target.data.type == "or" && trigger.data.type == "or") {
      tt.removeChild();
      tg.removeChild();
      tg.parentAdd({
        name: uuid("$_"),
        type: "or",
        children: Array.prototype.concat([], tt.child.children, tg.child.children)
      });
    }

    // 4) one node is dataNode and another is logic node(wrapper node)
    // dataNode will be merged into logic node
    else if (
      (target.data.type == "data" && trigger.data.type != "data") ||
      (trigger.data.type == "data" && target.data.type != "data")
    ) {
      if (target.data.type == "data") {
        tt.removeChild();
        tg.childAdd(tt.child);
      }
      else {
        tg.removeChild();
        tt.childAdd(tg.child);
      }
    }


    // _______________ UNTESTED _______________
    // 5) both are logic node but NOT the same type
    // andNode will be merged into orNode
    else {
      if (target.data.type == "and" && trigger.data.type == "or") {
        tt.removeChild();
        tg.childAdd(tt.child);
      }
      else if (trigger.data.type == "and" && target.data.type == "or") {
        tg.removeChild();
        tt.childAdd(tg.child);
      }
    }

    nodesUpdate(rootInit());

    // release memory
    innerReset();
  } // onDragEnd End


  return d3.drag()
    .on("start",onDragStart)
    .on("drag", onDrag)
    .on("end", onDragEnd);

})(); // nodeDrag END

function nodesUpdate (nodes) {
  var u = gMain.selectAll(".svg__node")
    .data(nodes.slice(1), function (d) { return d.data.name; });

  u.enter()
    .append("g")
    .attr("class", d => { return "svg__node svg__node-" + d.data.type; })
    .call(nodeDrag)
    .on("click", onCtrClick)
    .on("dblclick", onDataNodeDBLClick)
    .on("contextmenu", onNodeContextmenu)
    .each(function (d) {
      var self = d3.select(this);

      // add circle backgorund, circle is event-responsible
      self.append("circle")
        .attr("fill", d.children ? null : d.data.bind.color)
        .attr("r", d.r);

      // add text content for leaf nodes
      if (!d.children) {
        self.call(appendText, d);
        // self.append("text")
        //   .attr("class", "svg__text")
        //   .attr("y", -20)
        //   .html(`<tspan>&lt; ${d.data.name} &gt;</tspan>
        //   <tspan x="0" dy="20">性别=男</tspan>
        //   <tspan x="0" dy="20">年龄>30</tspan>
        //   <tspan x="0" dy="20">. . .</tspan>`);
      }
    })
    .attr("transform", "translate(" + [w / 2, h / 2] + ")")
    .merge(u)
    .sort(function (a, b) { return b.r - a.r; })
    .each(function (d) {
      // data rebine and change apprence
      d3.select(this).select("circle").datum(d).attr("r", d.r);
      // TODO: text should rebine if neccessory ... ...
    })
    .transition()
    .duration(800)
    .attr("transform", d => { return "translate(" + [d.x, d.y] + ")"; });
    

  u.exit()
    .attr("transform", d => { return "translate(" + [d.x, d.y] + ") scale(1) rotate(0)"; })
    .transition()
    .duration(400)
    .attr("transform", d => { return "translate(" + [d.x, d.y] + ") scale(0.01) rotate(90)"; })
    .remove();
}




logicalTree = {
  width: function (width) { // default: 1000
    if (!width) { return w; }
    w = width;
    return this;
  },
  height: function (height) { // default: 550
    if (!height) { return h; }
    h = height;
    return this;
  },
  vForm: function (v) { // Vue instance for pop window
    if (!v) { return vm; }
    vm = v;
    return this;
  },
  initialize: function (id) {
    svgInit(id);
    nodesUpdate(rootInit());
  },
  addDataNode: function (bind) {
    rData.children.push({
      name: uuid(),
      type: "data",
      bind: bind
    });
    nodesUpdate(rootInit());
  },
  clearTree: function () {
    rData.children = [];
    nodesUpdate(rootInit());
  },
  toString: function (space) {
    if (!space) { space = 0; }
    return JSON.stringify(rData, null, space);
  },
  toJSON: function () {
    return JSON.parse(this.toString());
  }
};

window.logicalTree = logicalTree;

})(window, d3);



